# Zindagi-Website
Website for my Dancing club that i founded last year. Buy merch, have a member login(Exclusive to members only), pay dues for the club and post your videos and photos for your account.
